import json
from collections import Counter
f = open("/Users/Feng/Documents/export2.json")
for line in f:
    g = json.loads(line)
f.close()
d = {}
for age in range (18, 45):

    d.update({age:[]})
for p in g['players']:
    #print (p['ratings'])
    byear = p['born']['year']
    for e in range (0, len(p['ratings'])-1):
        r = p['ratings'][e]
        rplus = p['ratings'][e+1]
        if rplus['season'] > r['season']:
            
            s = r['season']
            age = s - byear
            l = d[age]
            l.append(rplus['ovr']-r['ovr'])
            if rplus['ovr']-r['ovr'] == -7 and age == 23:
                print(p['firstName']+" "+p['lastName'])
                print(p['pid'])
            d.update({age:l})
t = 1/0
fout = open("/Users/Feng/Documents/Progs_out2.csv",'w')
fout.write("Age,Progression Amount,Frequency,Percentage\n")
for age in range (18, 45):
    print(age)
    l = Counter(d[age])
    if len(d[age]) > 0:
        total = 0
        for key in l.keys():
            total += key * l[key]
            if age < 36:
                fout.write(str(age)+","+str(key)+","+str(l[key])+","+str(100*l[key]/len(d[age]))+"\n")
        print(total/len(d[age]))
        print("sample size "+str(len(d[age])))
fout.close()
    


        
        
